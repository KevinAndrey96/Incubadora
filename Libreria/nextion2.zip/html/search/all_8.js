var searchData=
[
  ['readme',['readme',['../md_readme.html',1,'']]],
  ['release_20notes',['Release Notes',['../md_release_notes.html',1,'']]],
  ['read_5frtc_5ftime',['read_rtc_time',['../class_nex_rtc.html#a17230cd9342a905778fa4ee2e8609f02',1,'NexRtc::read_rtc_time(char *time, uint32_t len)'],['../class_nex_rtc.html#aa1afa1d516db55dfbbf650cbe5180eab',1,'NexRtc::read_rtc_time(char *time_type, uint32_t *number)'],['../class_nex_rtc.html#ac71de2cd6f7598f05a5115642714d490',1,'NexRtc::read_rtc_time(uint32_t *time, uint32_t len)']]]
];
