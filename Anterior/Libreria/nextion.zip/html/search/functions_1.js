var searchData=
[
  ['detachpop',['detachPop',['../class_nex_touch.html#af656640c1078a553287a68bf792dd291',1,'NexTouch']]],
  ['detachpush',['detachPush',['../class_nex_touch.html#a2bc36096119534344c2bcd8021b93289',1,'NexTouch']]],
  ['detachtimer',['detachTimer',['../class_nex_timer.html#a365d08df4623ce8a146e73ff9204d5cb',1,'NexTimer']]],
  ['digital_5fread',['digital_read',['../class_nex_gpio.html#a36386b97898f0960abda51c6010378eb',1,'NexGpio']]],
  ['digital_5fwrite',['digital_write',['../class_nex_gpio.html#aaea4cb428fa0a2e26927073c20ed64ac',1,'NexGpio']]],
  ['disable',['disable',['../class_nex_timer.html#ae016d7d39ede6cf813221b26691809f1',1,'NexTimer']]]
];
